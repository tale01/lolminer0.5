#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

PROFILE=EXAMPLE_MNX	

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"
./lolMiner --benchmark MNX $@
./lolMiner --benchmark AION $@
./lolMiner --benchmark BTG $@
./lolMiner --benchmark ZER $@
