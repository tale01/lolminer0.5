#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

PROFILE=EXAMPLE_BTG	

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --profile $PROFILE $@
